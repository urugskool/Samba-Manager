import { School, DivisionId, Enredo, EnredoThemeType } from '../types/carnaval';
import { cleanSchoolName } from '../utils/schoolNameUtils';
import { DIVISION_REGULATIONS, generateDefaultParadeComposition } from '../config/obrigatoriedadesConfig';

export type ParadeElementType =
  | 'comissao_frente'
  | 'casal_mspb'
  | 'abre_alas'
  | 'ala'
  | 'tripe'
  | 'baianas'
  | 'bateria'
  | 'alegoria'
  | 'passistas'
  | 'velha_guarda'
  | 'apoteose';

export interface ParadeScriptElement {
  id: string;
  orderNumber: number;
  type: ParadeElementType;
  name: string;
  categoryLabel: string;
  sectorNumber: number;
  sectorTitle: string;
  description: string;
  costumeDetails?: string;
  highlightPeople?: string;
  componentsCount: number;
  isAllegoryOrTripod?: boolean;
}

export interface ParadeSector {
  sectorNumber: number;
  title: string;
  themeSynopsis: string;
}

export interface ParadeScript {
  schoolId: string;
  schoolName: string;
  shortName: string;
  division: DivisionId;
  divisionLabel: string;
  enredoTitle: string;
  enredoTheme: EnredoThemeType;
  synopsis: string;
  carnavalesco: string;
  
  // Obrigatoriedades Homologadas
  obrigatoriedades: {
    totalComponentes: number;
    totalAlas: number;
    totalAlegorias: number;
    totalTripes: number;
    ritmistasCount: number;
    baianasCount: number;
    comissaoDeFrenteCount: number;
    componentesPorAla: number;
    casaisCount: number;
  };

  setores: ParadeSector[];
  elements: ParadeScriptElement[];
}

export class ParadeScriptService {
  private static scriptCache: Map<string, ParadeScript> = new Map();

  /**
   * Obtém ou gera o Roteiro Oficial do Desfile (Livro Abre-Alas) para uma escola
   */
  public static getOrGenerateParadeScript(school: School, division?: DivisionId): ParadeScript {
    const div = division || school.division;
    const enredoTitle = school.currentEnredo?.title || 'O Canto Sagrado da Passarela';
    const cacheKey = `${school.id}_${div}_${enredoTitle}`;

    if (this.scriptCache.has(cacheKey)) {
      return this.scriptCache.get(cacheKey)!;
    }

    const script = this.generateScript(school, div);
    this.scriptCache.set(cacheKey, script);
    return script;
  }

  private static generateScript(school: School, division: DivisionId): ParadeScript {
    const reg = DIVISION_REGULATIONS[division];
    const comp = school.paradeComposition || generateDefaultParadeComposition(school);
    const enredo = school.currentEnredo || {
      id: 'default_enr',
      title: 'A Festa da Raiz do Samba',
      themeType: 'Cultural' as EnredoThemeType,
      synopsis: 'Uma celebração às tradições imortais e aos baluartes do Carnaval.',
      qualityBoost: 10,
      cost: 150000
    };

    const divisionLabel = reg.divisionLabel;

    // Obrigatoriedades consolidadas
    const alegoriasCount = comp.alegorias || (division === 'especial' ? 5 : division === 'ouro' ? 3 : division === 'prata' ? 3 : division === 'bronze' ? 2 : 1);
    const tripesCount = comp.tripes || (division === 'especial' ? 2 : division === 'ouro' ? 1 : 0);
    const ritmistasCount = comp.ritmistas || (division === 'especial' ? 220 : division === 'ouro' ? 160 : division === 'prata' ? 130 : division === 'bronze' ? 95 : 80);
    const baianasCount = comp.baianas || (division === 'especial' ? 70 : division === 'ouro' ? 50 : division === 'prata' ? 40 : division === 'bronze' ? 30 : 15);
    const comissaoCount = comp.comissaoDeFrente || (division === 'especial' ? 14 : division === 'ouro' ? 14 : division === 'prata' ? 11 : 10);
    
    // Total de alas proporcionais à divisão e total de desfilantes
    const totalAlas = division === 'especial' ? 28 : division === 'ouro' ? 20 : division === 'prata' ? 16 : division === 'bronze' ? 12 : 9;
    const componentesTotal = comp.componentes || (division === 'especial' ? 2800 : division === 'ouro' ? 1100 : division === 'prata' ? 750 : division === 'bronze' ? 600 : 400);
    const componentesPorAla = Math.max(25, Math.round((componentesTotal - ritmistasCount - baianasCount - comissaoCount - 150) / totalAlas));

    // Gerar Setores Narrativos do Enredo
    const setores = this.generateSectors(enredo);

    // Gerar Elementos sequenciais do desfile
    const elements: ParadeScriptElement[] = [];
    let orderSeq = 1;

    // 1. Comissão de Frente (Abertura do Desfile)
    const cdfData = this.generateComissaoDeFrente(enredo, school, comissaoCount, setores[0]);
    elements.push({
      id: `cdf_${school.id}`,
      orderNumber: orderSeq++,
      type: 'comissao_frente',
      name: cdfData.name,
      categoryLabel: 'Comissão de Frente',
      sectorNumber: 1,
      sectorTitle: setores[0].title,
      description: cdfData.description,
      costumeDetails: cdfData.costume,
      highlightPeople: `Coreógrafo(a): ${school.staff.coreografo.name}`,
      componentsCount: comissaoCount,
      isAllegoryOrTripod: false
    });

    // 2. 1º Casal de Mestre-Sala e Porta-Bandeira
    const casalData = this.generateFirstCouple(enredo, school, setores[0]);
    elements.push({
      id: `casal_1_${school.id}`,
      orderNumber: orderSeq++,
      type: 'casal_mspb',
      name: casalData.name,
      categoryLabel: '1º Casal de MS & PB',
      sectorNumber: 1,
      sectorTitle: setores[0].title,
      description: casalData.description,
      costumeDetails: casalData.costume,
      highlightPeople: `1º Casal Oficial: ${school.staff.mestreSalaPortaBandeira.name}`,
      componentsCount: 2,
      isAllegoryOrTripod: false
    });

    // 3. Carro Abre-Alas (Alegoria 1)
    const abreAlasData = this.generateAbreAlas(enredo, school, setores[0]);
    elements.push({
      id: `alegoria_1_${school.id}`,
      orderNumber: orderSeq++,
      type: 'abre_alas',
      name: abreAlasData.name,
      categoryLabel: 'Abre-Alas (Alegoria 1)',
      sectorNumber: 1,
      sectorTitle: setores[0].title,
      description: abreAlasData.description,
      costumeDetails: abreAlasData.structure,
      highlightPeople: `Carnavalesco: ${school.staff.carnavalesco.name}`,
      componentsCount: 35,
      isAllegoryOrTripod: true
    });

    // Distribuir as alas entre os setores
    const alasNames = this.generateAlasNames(enredo, totalAlas);
    const alasPerSector = Math.ceil(totalAlas / setores.length);
    let alaIndex = 0;

    // Setor 1: Alas iniciais
    const setor1AlasCount = Math.min(alasPerSector, totalAlas - alaIndex);
    for (let i = 0; i < setor1AlasCount; i++) {
      const aName = alasNames[alaIndex];
      elements.push({
        id: `ala_${alaIndex + 1}_${school.id}`,
        orderNumber: orderSeq++,
        type: 'ala',
        name: `Ala ${alaIndex + 1}: ${aName.title}`,
        categoryLabel: `Ala ${alaIndex + 1}`,
        sectorNumber: 1,
        sectorTitle: setores[0].title,
        description: aName.description,
        costumeDetails: aName.costume,
        componentsCount: componentesPorAla,
        isAllegoryOrTripod: false
      });
      alaIndex++;
    }

    // Tripé 1 (se a escola possuir tripé)
    if (tripesCount >= 1) {
      const tripe1Data = this.generateTripod(enredo, 1, setores[0]);
      elements.push({
        id: `tripe_1_${school.id}`,
        orderNumber: orderSeq++,
        type: 'tripe',
        name: tripe1Data.name,
        categoryLabel: 'Elemento Cenográfico (Tripé 1)',
        sectorNumber: 1,
        sectorTitle: setores[0].title,
        description: tripe1Data.description,
        componentsCount: 2,
        isAllegoryOrTripod: true
      });
    }

    // Setor 2: Desenvolvimento
    const setor2Index = Math.min(1, setores.length - 1);
    const setor2 = setores[setor2Index];

    // Ala das Baianas tradicional no Setor 2
    const baianasData = this.generateBaianas(enredo, school, baianasCount, setor2);
    elements.push({
      id: `baianas_${school.id}`,
      orderNumber: orderSeq++,
      type: 'baianas',
      name: baianasData.name,
      categoryLabel: 'Ala das Baianas',
      sectorNumber: setor2.sectorNumber,
      sectorTitle: setor2.title,
      description: baianasData.description,
      costumeDetails: baianasData.costume,
      highlightPeople: `Mães do Samba • ${baianasCount} Baianas em giro cerimonial`,
      componentsCount: baianasCount,
      isAllegoryOrTripod: false
    });

    // Alas do Setor 2
    const setor2AlasCount = Math.min(alasPerSector, totalAlas - alaIndex);
    for (let i = 0; i < setor2AlasCount; i++) {
      const aName = alasNames[alaIndex];
      elements.push({
        id: `ala_${alaIndex + 1}_${school.id}`,
        orderNumber: orderSeq++,
        type: 'ala',
        name: `Ala ${alaIndex + 1}: ${aName.title}`,
        categoryLabel: `Ala ${alaIndex + 1}`,
        sectorNumber: setor2.sectorNumber,
        sectorTitle: setor2.title,
        description: aName.description,
        costumeDetails: aName.costume,
        componentsCount: componentesPorAla,
        isAllegoryOrTripod: false
      });
      alaIndex++;
    }

    // Alegoria 2 (se tiver mais de 1 alegoria)
    if (alegoriasCount >= 2) {
      const alegoria2Data = this.generateFloat(enredo, 2, setor2);
      elements.push({
        id: `alegoria_2_${school.id}`,
        orderNumber: orderSeq++,
        type: 'alegoria',
        name: alegoria2Data.name,
        categoryLabel: 'Carro Alegórico 2',
        sectorNumber: setor2.sectorNumber,
        sectorTitle: setor2.title,
        description: alegoria2Data.description,
        componentsCount: 30,
        isAllegoryOrTripod: true
      });
    }

    // Setor 3: Bateria, Passistas e Clímax
    const setor3Index = Math.min(2, setores.length - 1);
    const setor3 = setores[setor3Index];

    // Bateria Oficial
    const bateriaData = this.generateBateria(enredo, school, ritmistasCount, setor3);
    elements.push({
      id: `bateria_${school.id}`,
      orderNumber: orderSeq++,
      type: 'bateria',
      name: bateriaData.name,
      categoryLabel: 'Bateria dos Ritmistas',
      sectorNumber: setor3.sectorNumber,
      sectorTitle: setor3.title,
      description: bateriaData.description,
      costumeDetails: bateriaData.costume,
      highlightPeople: `Comandada pelo Mestre: ${school.staff.mestreBateria.name}`,
      componentsCount: ritmistasCount,
      isAllegoryOrTripod: false
    });

    // Ala dos Passistas
    elements.push({
      id: `passistas_${school.id}`,
      orderNumber: orderSeq++,
      type: 'passistas',
      name: `Ala dos Passistas: O Gingaço da Comunidade`,
      categoryLabel: 'Ala dos Passistas',
      sectorNumber: setor3.sectorNumber,
      sectorTitle: setor3.title,
      description: 'Ginga tradicional, malandragem e passos sincopados ao som dos tamborins.',
      costumeDetails: `Cores predominantes ${school.colors.primary} e ${school.colors.secondary} com leveza para o bailado.`,
      componentsCount: 45,
      isAllegoryOrTripod: false
    });

    // 2º Casal de MS e PB
    elements.push({
      id: `casal_2_${school.id}`,
      orderNumber: orderSeq++,
      type: 'casal_mspb',
      name: `2º Casal de Mestre-Sala e Porta-Bandeira: A Guardiã dos Mistérios`,
      categoryLabel: '2º Casal de MS & PB',
      sectorNumber: setor3.sectorNumber,
      sectorTitle: setor3.title,
      description: 'Elegância e reverência ao pavilhão secundário da escola.',
      componentsCount: 2,
      isAllegoryOrTripod: false
    });

    // Alas do Setor 3
    const setor3AlasCount = Math.min(alasPerSector, totalAlas - alaIndex);
    for (let i = 0; i < setor3AlasCount; i++) {
      const aName = alasNames[alaIndex];
      elements.push({
        id: `ala_${alaIndex + 1}_${school.id}`,
        orderNumber: orderSeq++,
        type: 'ala',
        name: `Ala ${alaIndex + 1}: ${aName.title}`,
        categoryLabel: `Ala ${alaIndex + 1}`,
        sectorNumber: setor3.sectorNumber,
        sectorTitle: setor3.title,
        description: aName.description,
        costumeDetails: aName.costume,
        componentsCount: componentesPorAla,
        isAllegoryOrTripod: false
      });
      alaIndex++;
    }

    // Alegoria 3 (se tiver 3 ou mais alegorias)
    if (alegoriasCount >= 3) {
      const alegoria3Data = this.generateFloat(enredo, 3, setor3);
      elements.push({
        id: `alegoria_3_${school.id}`,
        orderNumber: orderSeq++,
        type: 'alegoria',
        name: alegoria3Data.name,
        categoryLabel: 'Carro Alegórico 3',
        sectorNumber: setor3.sectorNumber,
        sectorTitle: setor3.title,
        description: alegoria3Data.description,
        componentsCount: 28,
        isAllegoryOrTripod: true
      });
    }

    // Tripé 2 (se a escola possuir 2 ou mais tripés)
    if (tripesCount >= 2) {
      const tripe2Data = this.generateTripod(enredo, 2, setor3);
      elements.push({
        id: `tripe_2_${school.id}`,
        orderNumber: orderSeq++,
        type: 'tripe',
        name: tripe2Data.name,
        categoryLabel: 'Elemento Cenográfico (Tripé 2)',
        sectorNumber: setor3.sectorNumber,
        sectorTitle: setor3.title,
        description: tripe2Data.description,
        componentsCount: 2,
        isAllegoryOrTripod: true
      });
    }

    // Setor 4: Apoteose e Alas Finais
    const setor4Index = setores.length - 1;
    const setor4 = setores[setor4Index];

    // Demais alas restantes até completar o total
    while (alaIndex < totalAlas) {
      const aName = alasNames[alaIndex];
      elements.push({
        id: `ala_${alaIndex + 1}_${school.id}`,
        orderNumber: orderSeq++,
        type: 'ala',
        name: `Ala ${alaIndex + 1}: ${aName.title}`,
        categoryLabel: `Ala ${alaIndex + 1}`,
        sectorNumber: setor4.sectorNumber,
        sectorTitle: setor4.title,
        description: aName.description,
        costumeDetails: aName.costume,
        componentsCount: componentesPorAla,
        isAllegoryOrTripod: false
      });
      alaIndex++;
    }

    // Carros intermediários adicionais (Alegoria 4, 5, etc.)
    for (let carNum = 4; carNum < alegoriasCount; carNum++) {
      const floatData = this.generateFloat(enredo, carNum, setor4);
      elements.push({
        id: `alegoria_${carNum}_${school.id}`,
        orderNumber: orderSeq++,
        type: 'alegoria',
        name: floatData.name,
        categoryLabel: `Carro Alegórico ${carNum}`,
        sectorNumber: setor4.sectorNumber,
        sectorTitle: setor4.title,
        description: floatData.description,
        componentsCount: 26,
        isAllegoryOrTripod: true
      });
    }

    // Velha Guarda tradicional antes do último carro
    elements.push({
      id: `velha_guarda_${school.id}`,
      orderNumber: orderSeq++,
      type: 'velha_guarda',
      name: `Velha Guarda: Os Baluartes e a Memória Imortal da ${school.shortName}`,
      categoryLabel: 'Velha Guarda',
      sectorNumber: setor4.sectorNumber,
      sectorTitle: setor4.title,
      description: `Com trajes a rigor nas cores ${school.colors.primary} e ${school.colors.secondary}, os fundadores e mestres abençoam a passagem triunfal.`,
      componentsCount: 30,
      isAllegoryOrTripod: false
    });

    // Última Alegoria: Carro da Apoteose
    if (alegoriasCount >= 1) {
      const lastFloatNum = alegoriasCount;
      const apoteoseData = this.generateApoteoseFloat(enredo, school, lastFloatNum, setor4);
      elements.push({
        id: `alegoria_apoteose_${school.id}`,
        orderNumber: orderSeq++,
        type: 'apoteose',
        name: apoteoseData.name,
        categoryLabel: `Última Alegoria (Carro ${lastFloatNum} - Apoteose)`,
        sectorNumber: setor4.sectorNumber,
        sectorTitle: setor4.title,
        description: apoteoseData.description,
        highlightPeople: 'Destaques de Luxo & Grande Escultura de Fechamento',
        componentsCount: 35,
        isAllegoryOrTripod: true
      });
    }

    return {
      schoolId: school.id,
      schoolName: school.name,
      shortName: school.shortName,
      division,
      divisionLabel,
      enredoTitle: enredo.title,
      enredoTheme: enredo.themeType,
      synopsis: enredo.synopsis,
      carnavalesco: school.staff.carnavalesco.name,
      obrigatoriedades: {
        totalComponentes: componentesTotal,
        totalAlas,
        totalAlegorias: alegoriasCount,
        totalTripes: tripesCount,
        ritmistasCount,
        baianasCount,
        comissaoDeFrenteCount: comissaoCount,
        componentesPorAla,
        casaisCount: 3
      },
      setores,
      elements
    };
  }

  /**
   * Gera os Setores Narrativos do Enredo
   */
  private static generateSectors(enredo: Enredo): ParadeSector[] {
    const theme = enredo.themeType;
    const title = enredo.title;

    switch (theme) {
      case 'Afro-brasileiro':
        return [
          {
            sectorNumber: 1,
            title: 'Setor 1: O Chamado dos Ancestrais e os Mistérios de Oió',
            themeSynopsis: 'Abertura mística revelando os orixás, divindades das águas e do fogo sagrado.'
          },
          {
            sectorNumber: 2,
            title: 'Setor 2: A Travessia das Águas e o Quilombo da Resistência',
            themeSynopsis: 'A fé inabalável que atravessou os mares e fincou raízes nos terreiros e senzalas.'
          },
          {
            sectorNumber: 3,
            title: 'Setor 3: O Rufar dos Tambores e a Força da Raça',
            themeSynopsis: 'A energia rítmica dos atabaques anunciando a soberania do povo negro.'
          },
          {
            sectorNumber: 4,
            title: 'Setor 4: Apoteose Negra: A Coroação da Dignidade',
            themeSynopsis: 'Celebração gloriosa na avenida com os mantos sagrados e a bênção dos orixás.'
          }
        ];

      case 'Histórico':
        return [
          {
            sectorNumber: 1,
            title: 'Setor 1: As Origens Coloniais e os Primeiros Caminhos',
            themeSynopsis: 'A gênese histórica, os desbravadores e o choque dos mundos.'
          },
          {
            sectorNumber: 2,
            title: 'Setor 2: O Ciclo das Riquezas e a Labuta do Povo',
            themeSynopsis: 'A extração do ouro, as fazendas e a força anônima dos trabalhadores.'
          },
          {
            sectorNumber: 3,
            title: 'Setor 3: Os Ideais Libertários e as Revoluções da Memória',
            themeSynopsis: 'Os heróis esquecidos que lutaram pela soberania e transformação social.'
          },
          {
            sectorNumber: 4,
            title: 'Setor 4: Apoteose: A História Escrita sob o Manto do Samba',
            themeSynopsis: 'O resgate triunfal do patrimônio cultural eternizado na pista.'
          }
        ];

      case 'Crítica Social':
        return [
          {
            sectorNumber: 1,
            title: 'Setor 1: O Despertar da Madrugada e o Suor da Periferia',
            themeSynopsis: 'O cotidiano do povo batalhador nos trens, becos e vielas da cidade.'
          },
          {
            sectorNumber: 2,
            title: 'Setor 2: As Promessas Não Cumpridas e as Correntes Invisíveis',
            themeSynopsis: 'A sátira fina e a denúncia poética da desigualdade e da burocracia.'
          },
          {
            sectorNumber: 3,
            title: 'Setor 3: A Voz dos Invisíveis que se Faz Gigante',
            themeSynopsis: 'A união comunitária, a solidariedade e a cultura popular como resistência.'
          },
          {
            sectorNumber: 4,
            title: 'Setor 4: Apoteose: O Brasil Real Coroado no Asfalto',
            themeSynopsis: 'O triunfo da dignidade popular em uma festa de luz e esperança.'
          }
        ];

      case 'Homenagem':
        return [
          {
            sectorNumber: 1,
            title: 'Setor 1: O Berço da Estrela e os Primeiros Acordes',
            themeSynopsis: 'A infância simples, o nascimento da vocação e o sonho precoce.'
          },
          {
            sectorNumber: 2,
            title: 'Setor 2: A Trajetória de Lutas e as Obras Imortais',
            themeSynopsis: 'A consagração artística, os palcos da vida e as criações inesquecíveis.'
          },
          {
            sectorNumber: 3,
            title: 'Setor 3: O Abraço do Povo e a Glória Nacional',
            themeSynopsis: 'O carinho dos fãs e a reverência dos mestres da cultura.'
          },
          {
            sectorNumber: 4,
            title: 'Setor 4: Apoteose: Aplausos Infinitos sob a Coroa do Samba',
            themeSynopsis: 'A consagração suprema do homenageado no altar sagrado do Carnaval.'
          }
        ];

      case 'Folclore & Lendas':
        return [
          {
            sectorNumber: 1,
            title: 'Setor 1: O Encanto das Matas e os Segredos da Meia-Noite',
            themeSynopsis: 'O mistério dos seres encantados e as lendas transmitidas pelos povos ancestrais.'
          },
          {
            sectorNumber: 2,
            title: 'Setor 2: O Auto dos Reis e as Danças do Brasil Profundo',
            themeSynopsis: 'O festejo popular, o boi-bumbá e as festas que encantam os sertões.'
          },
          {
            sectorNumber: 3,
            title: 'Setor 3: Ritos Mágicos e as Bençãos da Terra',
            themeSynopsis: 'A sabedoria dos pajés e caboclos em comunhão com a natureza.'
          },
          {
            sectorNumber: 4,
            title: 'Setor 4: Apoteose: O Grande Baile dos Encantados',
            themeSynopsis: 'A celebração mágica do imaginário brasileiro na avenida.'
          }
        ];

      default:
        return [
          {
            sectorNumber: 1,
            title: 'Setor 1: A Gênese Poética e a Abertura dos Portais',
            themeSynopsis: 'A inspiração criativa descortinando o universo fantástico do enredo.'
          },
          {
            sectorNumber: 2,
            title: 'Setor 2: O Encontro das Tradições e o Brilho Cultural',
            themeSynopsis: 'As narrativas centrais desfilando em cores, formas e riqueza estética.'
          },
          {
            sectorNumber: 3,
            title: 'Setor 3: O Canto Coletivo e a Vibração da Raiz',
            themeSynopsis: 'A cadência rítmica e a comunhão dos sambistas com a narrativa.'
          },
          {
            sectorNumber: 4,
            title: 'Setor 4: Apoteose: O Triunfo da Imaginação na Passarela',
            themeSynopsis: 'O clímax visual e a celebração da arte carnavalesca no encerramento.'
          }
        ];
    }
  }

  private static generateComissaoDeFrente(enredo: Enredo, school: School, count: number, sector: ParadeSector) {
    const theme = enredo.themeType;
    let name = 'Comissão de Frente: Os Guardiões da Sabedoria Ancestral';
    let description = 'Coreografia teatral impactante que dialoga diretamente com o público e jurados.';
    let costume = `Indumentária luxuosa nas cores ${school.colors.primary} e ${school.colors.secondary}, com efeitos especiais cênicos.`;

    if (theme === 'Afro-brasileiro') {
      name = 'Comissão de Frente: O Despertar dos Orixás no Templo Sagrado';
      description = `Coreografia ritualística onde ${count} bailarinos representam os sacerdotes invocando a força dos trovões e das águas sagradas.`;
      costume = 'Paramentos dourados, búzios africanos, saiotes tradicionais e cetros reluzentes.';
    } else if (theme === 'Histórico') {
      name = 'Comissão de Frente: Os Arautos da Memória e a Chama do Passado';
      description = `Dançarinos encenam o momento histórico em que os documentos sagrados ganham vida diante dos jurados.`;
      costume = 'Fardamento de época estilizado, veludos nobres e pergaminhos dourados cenográficos.';
    } else if (theme === 'Crítica Social') {
      name = 'Comissão de Frente: O Grito que Quebra as Mordaças do Silêncio';
      description = `Movimentos corporais vigorosos retratando a resistência popular e a busca incessante por liberdade.`;
      costume = 'Roupas utilitárias urbanas que se transformam em túnicas de arco-íris e esperança.';
    } else if (theme === 'Homenagem') {
      name = `Comissão de Frente: A Meninice e a Inspiração da Grande Obra`;
      description = `Interação cênica entre a figura do homenageado e os personagens icônicos criados ao longo de sua vida.`;
      costume = 'Trajes clássicos com tecidos acetinados e adereços de cabeça com instrumentos de arte.';
    }

    return { name, description, costume };
  }

  private static generateFirstCouple(enredo: Enredo, school: School, sector: ParadeSector) {
    const cleanName = cleanSchoolName(school);
    const theme = enredo.themeType;
    let name = `1º Casal de MS & PB: O Resplendor do Pavilhão Sagrado da ${school.shortName}`;
    let description = 'O casal oficial rodopia com elegância milimétrica, reverenciando os quatro cantos da passarela.';
    let costume = `Fantasia aristocrática em tons de ${school.colors.primary}, ${school.colors.secondary} e pedrarias reluzentes.`;

    if (theme === 'Afro-brasileiro') {
      name = '1º Casal de MS & PB: O Sol Dourado de Oió e a Brisa Suave de Oyá';
      description = 'O Mestre-Sala corteja com passos nobres a Porta-Bandeira, que gira com a leveza dos ventos ancestrais.';
      costume = 'Plumas de faisão imperiais, bordados em fios de ouro, cristais swarovski e resplendor solar.';
    } else if (theme === 'Histórico') {
      name = '1º Casal de MS & PB: A Nobreza dos Ideais e o Manto da Liberdade';
      description = 'Bailado clássico que une tradição do samba e refinamento cortesão em sintonia absoluta.';
      costume = 'Casaca bordada em pedrarias nobres, saiote rodado com motivos heráldicos e coroa bordada.';
    }

    return { name, description, costume };
  }

  private static generateAbreAlas(enredo: Enredo, school: School, sector: ParadeSector) {
    const theme = enredo.themeType;
    let name = `Abre-Alas: O Monumental Portal da ${school.shortName}`;
    let description = 'Carro abre-alas imponente com esculturas mecânicas e iluminação computadorizada de última geração.';
    let structure = `Acoplagem dupla com 45 metros de extensão, detalhes nas cores ${school.colors.primary} e ${school.colors.secondary}.`;

    if (theme === 'Afro-brasileiro') {
      name = 'Abre-Alas: O Palácio Sagrado dos Orixás e o Trono de Oió';
      description = 'Esculturas gigantes de leões africanos e a balança da justiça em chamas de LED douradas.';
      structure = 'Carro acoplado com cachoeiras cenográficas reais e efeito pirotécnico frio de faíscas.';
    } else if (theme === 'Histórico') {
      name = 'Abre-Alas: As Naus da Memória e o Portal da Descoberta';
      description = 'Representação monumental dos galeões e marcos históricos que fundaram a identidade nacional.';
      structure = 'Proa dourada estilizada, iluminação cênica âmbar e esculturas articuladas de deuses marinhos.';
    } else if (theme === 'Crítica Social') {
      name = 'Abre-Alas: O Grande Relógio da Vida e o Trem dos Batalhadores';
      description = 'Alegoria dinâmica com engrenagens gigantes em movimento simbolizando a labuta diária do povo.';
      structure = 'Chassis blindado estilizado com grafites artísticos de nomes consagrados da comunidade.';
    }

    return { name, description, structure };
  }

  private static generateFloat(enredo: Enredo, floatNumber: number, sector: ParadeSector) {
    const theme = enredo.themeType;
    let name = `Carro Alegórico ${floatNumber}: A Forja das Tradições`;
    let description = `Segunda alegoria enriquecendo visualmente o ${sector.title}.`;

    if (floatNumber === 2) {
      if (theme === 'Afro-brasileiro') {
        name = 'Carro 2: A Forja de Ogunhê e a Floresta de Oxóssi';
        description = 'Esculturas imensas do ferro forjado em contraste com o verde profundo das matas sagradas.';
      } else if (theme === 'Histórico') {
        name = 'Carro 2: O Ouro das Gerais e os Contrastes do Barroco';
        description = 'Resplendor barroco esculpido à mão com detalhes em folha de ouro e esculturas de querubins.';
      } else {
        name = `Carro 2: O Manto Encantado das Raízes Populares`;
        description = `Estrutura alegórica grandiosa retratando o coração temático do segundo setor narrativo.`;
      }
    } else if (floatNumber === 3) {
      if (theme === 'Afro-brasileiro') {
        name = 'Carro 3: O Banquete de Oxum e o Canto das Sereias de Iemanjá';
        description = 'Espelhos d’água, conchas gigantes e esculturas das divindades das águas com movimentos fluidos.';
      } else if (theme === 'Histórico') {
        name = 'Carro 3: O Clamor da Abolição e os Ecos do Quilombo';
        description = 'Muralhas cênicas rompidas simbolizando a conquista irreversível da liberdade e da cidadania.';
      } else {
        name = `Carro 3: A Sinfonia das Cores e a Dança do Povo`;
        description = `Alegoria festiva com carros de som integrados e destaques de luxo celebrando a cultura.`;
      }
    } else {
      name = `Carro ${floatNumber}: A Sabedoria dos Mestres e o Futuro que Brota`;
      description = `Composição cênica que pavimenta a transição para a apoteose final do desfile.`;
    }

    return { name, description };
  }

  private static generateTripod(enredo: Enredo, tripNum: number, sector: ParadeSector) {
    const theme = enredo.themeType;
    let name = `Tripé Cenográfico ${tripNum}: O Altar dos Mistérios`;
    let description = 'Elemento cenográfico móvel tripulado por 2 destaques temáticos.';

    if (tripNum === 1) {
      if (theme === 'Afro-brasileiro') {
        name = 'Tripé 1: A Pedra do Trovão de Ayrá';
        description = 'Tripé cenográfico em formato de monólito com efeitos de fumaça e relâmpagos cenográficos.';
      } else {
        name = 'Tripé 1: O Pergaminho dos Sonhos Imortais';
        description = 'Elemento móvel articulado abrindo caminho entre as alas temáticas com efeito visual.';
      }
    } else {
      name = `Tripé 2: A Arca da Sabedoria Popular`;
      description = 'Elemento cenográfico refinado com luzes de LED integradas e adereçamento artesanal.';
    }

    return { name, description };
  }

  private static generateBaianas(enredo: Enredo, school: School, count: number, sector: ParadeSector) {
    const theme = enredo.themeType;
    let name = `Ala das Baianas: As Mães d’Água e as Guardiãs da Tradição`;
    let description = `${count} baianas rodando simultaneamente em perfeita harmonia, enchendo a pista de axé e nostalgia.`;
    let costume = `Vestido rodado com anáguas de renda engomada, turbantes cravejados de miçangas nas cores ${school.colors.primary}.`;

    if (theme === 'Afro-brasileiro') {
      name = 'Ala das Baianas: As Iabás de Oió e o Manto de Rendilhas Douradas';
      description = 'O mais emocionante momento do setor: as mães do samba girando e espalhando perfume de alfazema.';
      costume = 'Bordado richelieu genuíno, panos da costa autênticos e fios de contas sagradas consagradas.';
    } else if (theme === 'Histórico') {
      name = 'Ala das Baianas: As Matriarcas das Gerais e o Rosário da Fé';
      description = 'Reverência solene à ancestralidade feminina que manteve viva a religiosidade popular.';
      costume = 'Veludo branco com acabamento prateado, medalhões religiosos e turbantes imperiais.';
    }

    return { name, description, costume };
  }

  private static generateBateria(enredo: Enredo, school: School, count: number, sector: ParadeSector) {
    const theme = enredo.themeType;
    let name = `Bateria da ${school.shortName}: O Coração Pulsante da Comunidade`;
    let description = `${count} ritmistas sustentando o andamento rítmico clássico com paradinhas e bossas antológicas.`;
    let costume = `Fantasia leve e anatômica nas cores ${school.colors.primary} e ${school.colors.secondary}, permitindo total mobilidade aos músicos.`;

    if (theme === 'Afro-brasileiro') {
      name = 'Bateria: Os Guerreiros de Ayrá e o Rufar do Trovão de Xangô';
      description = 'Caixas e surdos marcantes executando desenhos rítmicos que arrepiam as arquibancadas no recuo.';
      costume = 'Guerreiros de ferro e cobre com capacetes estilizados e braçadeiras de couro sagrado.';
    } else if (theme === 'Histórico') {
      name = 'Bateria: Os Tambores da Resistência e os Clarins da Vitória';
      description = 'Cadência pesada com repiques cortantes e paradinhas sincronizadas com a marcha do samba.';
      costume = 'Casacas de gala estilizadas com botoaduras de prata e chapéus com plumas das cores da escola.';
    }

    return { name, description, costume };
  }

  private static generateApoteoseFloat(enredo: Enredo, school: School, floatNum: number, sector: ParadeSector) {
    const cleanName = cleanSchoolName(school);
    const theme = enredo.themeType;
    let name = `Carro ${floatNum} (Apoteose): A Coroação da ${school.shortName} na Eternidade`;
    let description = 'Alegoria de fechamento monumental que sela o desfile sob chuva de papel picado e aplausos efusivos.';

    if (theme === 'Afro-brasileiro') {
      name = `Carro ${floatNum} (Apoteose): O Reino Eterno de Oió e a Paz sobre a Terra`;
      description = 'A deusa Oxum e Xangô coroados no cume da escultura mais alta do Carnaval, abençoando o povo com axé.';
    } else if (theme === 'Histórico') {
      name = `Carro ${floatNum} (Apoteose): O Templo da Memória Nacional e o Triunfo Popular`;
      description = 'Uma apoteose de luz dourada com as figuras heróicas da história unidas em um abraço de esperança.';
    } else {
      name = `Carro ${floatNum} (Apoteose): O Grande Espelho da Poesia e o Aplauso do Povo`;
      description = `A celebração máxima do pavilhão da ${school.shortName}, encerrando o desfile com emoção inesquecível.`;
    }

    return { name, description };
  }

  /**
   * Gera uma lista poética e rica de nomes de alas temáticas baseadas no enredo
   */
  private static generateAlasNames(enredo: Enredo, totalAlas: number): Array<{ title: string; description: string; costume: string }> {
    const theme = enredo.themeType;
    const pool = THEMATIC_ALAS_POOLS[theme] || THEMATIC_ALAS_POOLS['Cultural'];
    const result: Array<{ title: string; description: string; costume: string }> = [];

    for (let i = 0; i < totalAlas; i++) {
      if (i < pool.length) {
        result.push(pool[i]);
      } else {
        // Variações elegantes para preencher alas remanescentes
        const base = pool[i % pool.length];
        result.push({
          title: `${base.title} - Segunda Geração`,
          description: `Variação estética e rítmica sobre ${base.description}`,
          costume: `Harmonização visual complementar nas cores da ala precedente.`
        });
      }
    }

    return result;
  }
}

// Bancos de nomes e descrições poéticas de alas para cada gênero de enredo
const THEMATIC_ALAS_POOLS: Record<string, Array<{ title: string; description: string; costume: string }>> = {
  'Afro-brasileiro': [
    { title: 'Os Sacerdotes do Fogo Ancestral', description: 'Invocação aos primeiros mestres que guardaram as chamas do conhecimento.', costume: 'Túnicas rubras com detalhes em cobre e adornos de búzios.' },
    { title: 'O Voo das Borboletas de Oyá', description: 'A leveza dos ventos que anunciam a tempestade de coragem.', costume: 'Asas de tecido holográfico que ondulam ao girar na pista.' },
    { title: 'Os Ferreiros da Forja Sagrada', description: 'Homenagem aos artesãos do ferro e à proteção de Ogunhê.', costume: 'Peitorais prateados esculpidos com marretas cenográficas leves.' },
    { title: 'As Guardiãs das Águas Doces', description: 'A doçura e a fertilidade que brotam das cachoeiras sagradas.', costume: 'Vestes douradas reluzentes com espelhos de mão e miçangas.' },
    { title: 'Os Caçadores de Uma Flecha Só', description: 'A fartura das matas virgens e a pontaria certeira de Oxóssi.', costume: 'Fantasias em tons de esmeralda com arcos estilizados e folhagens.' },
    { title: 'A Dança das Iabás no Terreiro', description: 'A reverência às divindades femininas da criação e da harmonia.', costume: 'Saiotes brancos e azuis com fitas sagradas e flores de lótus.' },
    { title: 'Os Mensageiros da Encruzilhada', description: 'A comunicação cósmica que abre todos os caminhos para o samba.', costume: 'Capas em preto e vermelho com cartolas requintadas e cetros.' },
    { title: 'A Travessia do Mar Sagrado', description: 'A dor e a bravura dos que atravessaram o oceano sem perder a fé.', costume: 'Tecidos em dégradé azul-marinho com cordas náuticas douradas.' },
    { title: 'Os Quilombolas da Serra da Barriga', description: 'O grito de liberdade de Zumbi e Dandara que nunca se calou.', costume: 'Trajes de guerreiros com lanças cênicas e couros ecológicos.' },
    { title: 'O Toque dos Ilús e Atabaques', description: 'A transmissão oral das melodias sagradas pelos alabês.', costume: 'Túnicas com instrumentos musicais bordados em fios de ouro.' },
    { title: 'As Ervas Sagradas de Ossaim', description: 'A medicina das folhas que cura as feridas da alma e do corpo.', costume: 'Fantasias verdes com ramagens medicinais estilizadas e cabaças.' },
    { title: 'A Coroa de Prata de Oxalufã', description: 'A paz, a paciência e a sabedoria dos mais velhos.', costume: 'Indumentárias inteiramente alvas com detalhes em prata pura.' },
    { title: 'Os Filhos do Trovão de Oió', description: 'A força da justiça que não tolera a covardia nem o engano.', costume: 'Saiotes carmesim com machados duplos de Xangô bordados.' },
    { title: 'O Manto Estrelado de Yemanjá', description: 'O abraço maternal do oceano que acolhe todas as preces.', costume: 'Tules translúcidos azuis com pérolas e conchas marítimas.' },
    { title: 'As Lavadeiras do Dique do Tororó', description: 'A alegria do trabalho cotidiano lavado nas águas da esperança.', costume: 'Vestimentas brancas tradicionais com trouxas de flores perfumadas.' },
    { title: 'A Resistência dos Blocos Afros', description: 'O renascimento estético e musical do Ilê Aiyê e Olodum.', costume: 'Cores quentes da África com estampas geométricas exclusivas.' },
    { title: 'Os Baluartes do Jongo da Serrinha', description: 'A raiz do samba de roda que deu origem às escolas de samba.', costume: 'Chita estampada colorida com chapéus de palha enfeitados.' },
    { title: 'A Chama da Liberdade que Não Apaga', description: 'A apoteose da consciência negra que ilumina o futuro.', costume: 'Fantasias solares douradas com resplendores incandescentes.' },
    { title: 'Os Pescadores da Noite de Luar', description: 'A comunhão do homem simples com a generosidade do mar.', costume: 'Redes cenográficas douradas com peixes prateados em relevo.' },
    { title: 'A Festa do Bonfim e as Fitas de Axé', description: 'O sincretismo brasileiro onde a fé abraça todas as cores.', costume: 'Milhares de fitinhas multicoloridas flutuando em leques cênicos.' },
    { title: 'Os Reis e Rainhas do Maracatu', description: 'A nobreza dos cortejos coroada sob o sol de Pernambuco.', costume: 'Mantos de brocado real com golas altas e coroas reluzentes.' },
    { title: 'A Cura Ancestral dos Pajés e Curandeiros', description: 'A aliança mística entre indígenas e africanos no Brasil.', costume: 'Penachos e colares de sementes amazônicas combinados com búzios.' },
    { title: 'A Bênção dos Pretos Velhos da Umbanda', description: 'A humildade, o cachimbo de paz e a palavra de consolo.', costume: 'Roupas simples em linho cru com terços de contas e batinas.' },
    { title: 'A Alvorada da Vitória do Povo', description: 'O amanhecer dos direitos conquistados no asfalto sagrado.', costume: 'Fantasias em branco e ouro celebrando a consagração suprema.' },
    { title: 'Os Dançarinos do Tambor de Crioula', description: 'A cadência maranhense com a força do toque de mão.', costume: 'Saias rodadas florais em cores vivas com guizos sonoros.' },
    { title: 'A Herança dos Griôs da África', description: 'Os contadores de histórias que mantiveram a memória viva.', costume: 'Túnicas elegantes em algodão cru com mapas ancestrais bordados.' },
    { title: 'Os Mestres de Capoeira e o Berimbau', description: 'A arte-luta que enganou a opressão com a ginga do corpo.', costume: 'Abadás brancos com berimbaus cenográficos de costas.' },
    { title: 'O Renascimento no Asfalto da Sapucaí', description: 'A consagração do desfile como o maior espetáculo da Terra.', costume: 'Plumas majestosas com as cores oficiais da agremiação.' }
  ],

  'Histórico': [
    { title: 'Os Navegantes das Caravelas do Infinito', description: 'A ousadia de cruzar oceanos desconhecidos em busca de novos mundos.', costume: 'Fardas de marinheiros do século XVI estilizadas com mapas náuticos.' },
    { title: 'O Encontro dos Mundos no Litoral', description: 'O impacto do contato entre nativos da terra e os recém-chegados.', costume: 'Combinação de elementos indígenas e armaduras de metal leve.' },
    { title: 'Os Bandeirantes e as Veredas do Sertão', description: 'A marcha pelas matas fechadas e o desbravamento dos interiores.', costume: 'Gibões de couro com botas e chapéus de aba larga.' },
    { title: 'Os Garimpeiros das Minas de Ouro', description: 'A febre do metal precioso que transformou o coração do Brasil.', costume: 'Fantasias com bateias douradas e pepitas cenográficas reluzentes.' },
    { title: 'O Barroco de Aleijadinho em Pedra-Sabão', description: 'A genialidade artística esculpida no sofrimento e na superação.', costume: 'Túnicas esculpidas com textura de pedra e querubins dourados.' },
    { title: 'A Inconfidência e o Grito de Tiradentes', description: 'O sonho de uma pátria livre sufocado pela forca imperial.', costume: 'Trajes coloniais com laços e o dístico da bandeira libertária.' },
    { title: 'A Corte Real Desembarca no Rio', description: 'A chegada da família real e a modernização da cidade de São Sebastião.', costume: 'Casacas imperiais com perucas aristocráticas e condecorações.' },
    { title: 'O Grito do Ipiranga e a Independência', description: 'O rompimento oficial com a metrópole sob a espada de Pedro I.', costume: 'Uniformes da guarda de honra imperial com dragoneiras douradas.' },
    { title: 'A Luta dos Alfaiates na Bahia', description: 'A revolta popular e democrática que antecedeu os grandes movimentos.', costume: 'Trajes de alfaiates populares com tesouras e panos de linho.' },
    { title: 'A Ferrovia e o Apito do Progresso', description: 'A chegada dos trens a vapor ligando os morros ao cais do porto.', costume: 'Fardas de maquinistas estilizadas com engrenagens de cobre.' },
    { title: 'A Abolição Inacabada e a Favela que Nasce', description: 'A assinatura da Lei Áurea e o abandono dos libertos nos morros.', costume: 'Roupas em patchwork rústico retratando a fundação dos morros cariocas.' },
    { title: 'A Revolta da Vacina e o Povo nas Ruas', description: 'A resistência do cidadão comum contra as imposições higienistas.', costume: 'Trajes do início do século XX com cartolas e barricadas cenográficas.' },
    { title: 'A Era de Ouro do Rádio na Cinelândia', description: 'As grandes cantoras e os programas de auditório que uniram o país.', costume: 'Vestidos de cetim com microfones vintage e estolas prateadas.' },
    { title: 'A Construção de Brasília no Planalto Central', description: 'Os candangos erguendo a capital dos traços futuristas no cerrado.', costume: 'Macacões de operários estilizados com pranchetas e maquetes de Niemeyer.' },
    { title: 'A Bossa Nova e o Canto do Barquinho', description: 'O Rio de Janeiro encantando o mundo com a sutileza do violão.', costume: 'Trajes casuais elegantes dos anos 60 em tons de azul e branco.' },
    { title: 'Os Festivais da Canção e a Resistência', description: 'A juventude cantando contra a censura com poesia afiada.', costume: 'Violões cênicos com letras de músicas históricas estampadas.' },
    { title: 'A Diretas Já e o Rio que Pede Democracia', description: 'O milhão de pessoas na Candelária exigindo o voto soberano.', costume: 'Camisetas amarelas com faixas libertárias e pombas da paz.' },
    { title: 'O Carnaval como Guardião da Verdadeira História', description: 'A consagração do samba como o livro que o povo escreveu.', costume: 'Fantasias triunfantes nas cores oficiais com pergaminhos gigantes.' }
  ],

  'Crítica Social': [
    { title: 'Os Trabalhadores da Madrugada', description: 'Os que acordam antes do sol nascer para mover a máquina da cidade.', costume: 'Uniformes operários retrabalhados com tecidos luminosos e crachás.' },
    { title: 'O Labirinto da Burocracia e os Carimbos', description: 'A crítica bem-humorada às filas e aos obstáculos do cidadão comum.', costume: 'Fantasias feitas de formulários burocráticos gigantes e carimbos vermelhos.' },
    { title: 'A Luta pelo Pão de Cada Dia', description: 'A inflação, o custo de vida e a arte de fazer milagres com o salário.', costume: 'Cestas básicas douradas com notas de dinheiro alegóricas.' },
    { title: 'O Trem Lotado da Central do Brasil', description: 'O sufoco e a solidariedade dos passageiros nos trilhos do subúrbio.', costume: 'Fantasias inspiradas nos vagões metálicos com janelas e catracas.' },
    { title: 'Os Sonhos que Brotam na Favela', description: 'O talento dos jovens da periferia nas artes, na ciência e no esporte.', costume: 'Roupas esportivas coloridas com asas douradas nascendo das costas.' },
    { title: 'A Voz dos Vendedores Ambulantes', description: 'A poesia do pregão nas praias e trens garantindo o sustento.', costume: 'Caixas de isopor estilizadas com biscoitos e mate cenográficos.' },
    { title: 'A Fome que Ninguém Quer Ver', description: 'O alerta pungente contra a miséria que ainda envergonha a nação.', costume: 'Pratos vazios transformados em tamborins sonoros de protesto.' },
    { title: 'A Esperança que Não se Rende', description: 'A força da comunidade unida que ergue escolas, creches e laços.', costume: 'Tijolos cenográficos dourados construindo castelos de dignidade.' },
    { title: 'O Brasil dos Sem Voz e Sem Vez', description: 'A memória dos que tombaram lutando por direitos e justiça.', costume: 'Túnicas em preto e branco que se iluminam ao comando dos jurados.' },
    { title: 'A Farra dos Poderosos nos Banquetes', description: 'A ironia mordaz aos privilégios dos que governam de costas para o povo.', costume: 'Fantasias rocambolescas de reis e rainhas do deboche palaciano.' },
    { title: 'A Educação que Transforma o Destino', description: 'O livro e o lápis como as maiores armas contra a opressão.', costume: 'Lápis e cadernos gigantes em asas multicoloridas de estudantes.' },
    { title: 'O Abraço da Comunidade que Salva', description: 'O Carnaval como o único momento do ano onde o povo é rei.', costume: 'Mantos majestosos populares com coroas de lata reluzente.' }
  ],

  'Cultural': [
    { title: 'O Baile das Máscaras Venezianas', description: 'A elegância dos antigos carnavais de salão que inspiraram o Rio.', costume: 'Máscaras de bico nobre com casacas acetinadas e plumas suaves.' },
    { title: 'O Zé Pereira e o Bumbo da Folia', description: 'O pioneiro que colocou o tambor nas ruas e iniciou a festa popular.', costume: 'Bumbos antigos de couro com fraques estilizados do século XIX.' },
    { title: 'As Pastorinhas e os Cordões de Carnaval', description: 'A doçura dos ranchos carnavalescos e suas marchas românticas.', costume: 'Saias rodadas com pandeiros floridos e fitas de seda.' },
    { title: 'A Malandragem da Lapa e a Ginga do Linho', description: 'A navalha no bolso, o chapéu Panamá e a elegância do malandro.', costume: 'Ternos de linho branco impecáveis com lenços vermelhos de seda.' },
    { title: 'A Criação das Escolas de Samba', description: 'A fundação da Deixa Falar no Estácio e a invenção do surdo de marcação.', costume: 'Fantasias históricas com instrumentos artesanais originais.' },
    { title: 'Os Clássicos Sambas-Enredo Imortais', description: 'As melodias que o país inteiro canta de cor há gerações.', costume: 'Pautas musicais flutuantes com notas de ouro e claves de sol.' },
    { title: 'A Explosão dos Blocos de Rua', description: 'A alegria democrática e irreverente que ocupa todas as esquinas.', costume: 'Fantasias divertidas e coloridas com confetes e serpentinas.' },
    { title: 'A Festa de Momo no Templo do Samba', description: 'A coroação do Carnaval carioca como Patrimônio Imaterial da Humanidade.', costume: 'Mantos imperiais majestosos com coroas de ouro e o pavilhão.' }
  ]
};
